--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 17.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "TreinamentoBI";
--
-- Name: TreinamentoBI; Type: DATABASE; Schema: -; Owner: admint2mbi
--

CREATE DATABASE "TreinamentoBI" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE "TreinamentoBI" OWNER TO admint2mbi;

\connect "TreinamentoBI"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: t2mbi; Type: SCHEMA; Schema: -; Owner: admint2mbi
--

CREATE SCHEMA t2mbi;


ALTER SCHEMA t2mbi OWNER TO admint2mbi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: beneficio; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.beneficio (
    bene_cd_beneficio integer NOT NULL,
    tibe_cd_tipo_beneficio integer NOT NULL,
    bene_nm_beneficio character varying NOT NULL,
    bene_vl_beneficio double precision NOT NULL,
    bene_vl_descontado double precision NOT NULL,
    bene_ds_beneficio character varying NOT NULL,
    bene_in_status character(1) NOT NULL
);


ALTER TABLE t2mbi.beneficio OWNER TO admint2mbi;

--
-- Name: beneficio_bene_cd_beneficio_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.beneficio_bene_cd_beneficio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.beneficio_bene_cd_beneficio_seq OWNER TO admint2mbi;

--
-- Name: beneficio_bene_cd_beneficio_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.beneficio_bene_cd_beneficio_seq OWNED BY t2mbi.beneficio.bene_cd_beneficio;


--
-- Name: colaborador; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.colaborador (
    cola_cd_colaborador integer NOT NULL,
    grhi_cd_grau_hierarquico integer NOT NULL,
    ticn_cd_tipo_contrato integer NOT NULL,
    turn_cd_turno integer NOT NULL,
    gred_cd_grau_educacional integer NOT NULL,
    natu_cd_naturalidade integer NOT NULL,
    naci_cd_nacionalidade integer NOT NULL,
    esci_cd_estado_civil integer NOT NULL,
    gene_cd_genero integer NOT NULL,
    cola_nr_registro integer NOT NULL,
    cola_nm_colaborador character varying NOT NULL,
    cola_dt_nascimento date NOT NULL,
    cola_nr_cpf bigint NOT NULL,
    cola_nr_rg bigint NOT NULL,
    cola_dt_expedicao_rg date NOT NULL,
    cola_sg_orgao_emissor_rg character varying NOT NULL,
    cola_nr_titulo_eleitor bigint NOT NULL,
    cola_nr_zona_eleitoral integer NOT NULL,
    cola_tx_secao_eleitoral character varying NOT NULL,
    cola_nr_ctps bigint NOT NULL,
    cola_nr_serie_ctps bigint NOT NULL,
    cola_nr_reservista bigint NOT NULL,
    cola_nm_banco character varying NOT NULL,
    cola_nr_agencia integer NOT NULL,
    cola_nr_conta character varying NOT NULL,
    cola_nr_pis bigint NOT NULL,
    cola_dt_admissao date NOT NULL,
    cola_dt_demissao date,
    cola_tx_motivo_demissao character varying,
    cola_vl_salario double precision NOT NULL
);


ALTER TABLE t2mbi.colaborador OWNER TO admint2mbi;

--
-- Name: colaborador_beneficio; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.colaborador_beneficio (
    bene_cd_beneficio integer NOT NULL,
    cola_cd_colaborador integer NOT NULL
);


ALTER TABLE t2mbi.colaborador_beneficio OWNER TO admint2mbi;

--
-- Name: colaborador_cola_cd_colaborador_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.colaborador_cola_cd_colaborador_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.colaborador_cola_cd_colaborador_seq OWNER TO admint2mbi;

--
-- Name: colaborador_cola_cd_colaborador_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.colaborador_cola_cd_colaborador_seq OWNED BY t2mbi.colaborador.cola_cd_colaborador;


--
-- Name: colaborador_contrato; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.colaborador_contrato (
    cotr_cd_contrato integer NOT NULL,
    cola_cd_colaborador integer NOT NULL,
    coco_in_status character(1) NOT NULL
);


ALTER TABLE t2mbi.colaborador_contrato OWNER TO admint2mbi;

--
-- Name: colaborador_departamento; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.colaborador_departamento (
    cola_cd_colaborador integer NOT NULL,
    depa_cd_departamento integer NOT NULL,
    code_in_status character(1) NOT NULL
);


ALTER TABLE t2mbi.colaborador_departamento OWNER TO admint2mbi;

--
-- Name: contato; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.contato (
    cont_cd_contato integer NOT NULL,
    cola_cd_colaborador integer NOT NULL,
    tico_cd_tipo_contato integer NOT NULL,
    cont_ds_contato character varying NOT NULL
);


ALTER TABLE t2mbi.contato OWNER TO admint2mbi;

--
-- Name: contato_cont_cd_contato_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.contato_cont_cd_contato_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.contato_cont_cd_contato_seq OWNER TO admint2mbi;

--
-- Name: contato_cont_cd_contato_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.contato_cont_cd_contato_seq OWNED BY t2mbi.contato.cont_cd_contato;


--
-- Name: contrato; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.contrato (
    cotr_cd_contrato integer NOT NULL,
    cotr_nm_contrato character varying NOT NULL,
    cotr_dt_inicio_contrato date NOT NULL,
    cotr_dt_expiracao_contrato date NOT NULL,
    cotr_in_status character(1) NOT NULL
);


ALTER TABLE t2mbi.contrato OWNER TO admint2mbi;

--
-- Name: contrato_cotr_cd_contrato_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.contrato_cotr_cd_contrato_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.contrato_cotr_cd_contrato_seq OWNER TO admint2mbi;

--
-- Name: contrato_cotr_cd_contrato_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.contrato_cotr_cd_contrato_seq OWNED BY t2mbi.contrato.cotr_cd_contrato;


--
-- Name: departamento; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.departamento (
    depa_cd_departamento integer NOT NULL,
    depa_nm_departamento character varying NOT NULL
);


ALTER TABLE t2mbi.departamento OWNER TO admint2mbi;

--
-- Name: departamento_depa_cd_departamento_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.departamento_depa_cd_departamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.departamento_depa_cd_departamento_seq OWNER TO admint2mbi;

--
-- Name: departamento_depa_cd_departamento_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.departamento_depa_cd_departamento_seq OWNED BY t2mbi.departamento.depa_cd_departamento;


--
-- Name: dependente; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.dependente (
    depe_cd_dependente integer NOT NULL,
    cola_cd_colaborador integer NOT NULL,
    tire_cd_tipo_relacionamento integer NOT NULL,
    depe_nm_dependente character varying NOT NULL,
    depe_nr_cpf bigint NOT NULL,
    depe_nr_rg bigint NOT NULL,
    depe_dt_nascimento date NOT NULL
);


ALTER TABLE t2mbi.dependente OWNER TO admint2mbi;

--
-- Name: dependente_depe_cd_dependente_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.dependente_depe_cd_dependente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.dependente_depe_cd_dependente_seq OWNER TO admint2mbi;

--
-- Name: dependente_depe_cd_dependente_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.dependente_depe_cd_dependente_seq OWNED BY t2mbi.dependente.depe_cd_dependente;


--
-- Name: estado_civil; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.estado_civil (
    esci_cd_estado_civil integer NOT NULL,
    esci_nm_estado_civil character varying NOT NULL
);


ALTER TABLE t2mbi.estado_civil OWNER TO admint2mbi;

--
-- Name: estado_civil_esci_cd_estado_civil_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.estado_civil_esci_cd_estado_civil_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.estado_civil_esci_cd_estado_civil_seq OWNER TO admint2mbi;

--
-- Name: estado_civil_esci_cd_estado_civil_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.estado_civil_esci_cd_estado_civil_seq OWNED BY t2mbi.estado_civil.esci_cd_estado_civil;


--
-- Name: ferias; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.ferias (
    feri_cd_ferias integer NOT NULL,
    cola_cd_colaborador integer NOT NULL,
    feri_dt_inicio date NOT NULL,
    feri_dt_final date NOT NULL,
    feri_dt_vencimento date NOT NULL,
    feri_nr_dias_ferias integer NOT NULL,
    feri_nr_dias_subsidios integer NOT NULL,
    feri_vl_abono double precision NOT NULL,
    feri_in_status character(1) NOT NULL,
    feri_ds_ferias character varying
);


ALTER TABLE t2mbi.ferias OWNER TO admint2mbi;

--
-- Name: ferias_feri_cd_ferias_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.ferias_feri_cd_ferias_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.ferias_feri_cd_ferias_seq OWNER TO admint2mbi;

--
-- Name: ferias_feri_cd_ferias_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.ferias_feri_cd_ferias_seq OWNED BY t2mbi.ferias.feri_cd_ferias;


--
-- Name: genero; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.genero (
    gene_cd_genero integer NOT NULL,
    gene_nm_genero character varying NOT NULL
);


ALTER TABLE t2mbi.genero OWNER TO admint2mbi;

--
-- Name: genero_gene_cd_genero_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.genero_gene_cd_genero_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.genero_gene_cd_genero_seq OWNER TO admint2mbi;

--
-- Name: genero_gene_cd_genero_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.genero_gene_cd_genero_seq OWNED BY t2mbi.genero.gene_cd_genero;


--
-- Name: grau_educacional; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.grau_educacional (
    gred_cd_grau_educacional integer NOT NULL,
    gred_nm_grau_educacional character varying NOT NULL
);


ALTER TABLE t2mbi.grau_educacional OWNER TO admint2mbi;

--
-- Name: grau_educacional_gred_cd_grau_educacional_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.grau_educacional_gred_cd_grau_educacional_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.grau_educacional_gred_cd_grau_educacional_seq OWNER TO admint2mbi;

--
-- Name: grau_educacional_gred_cd_grau_educacional_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.grau_educacional_gred_cd_grau_educacional_seq OWNED BY t2mbi.grau_educacional.gred_cd_grau_educacional;


--
-- Name: grau_hierarquico; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.grau_hierarquico (
    grhi_cd_grau_hierarquico integer NOT NULL,
    grhi_nm_grau_hierarquico character varying NOT NULL
);


ALTER TABLE t2mbi.grau_hierarquico OWNER TO admint2mbi;

--
-- Name: grau_hierarquico_grhi_cd_grau_hierarquico_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.grau_hierarquico_grhi_cd_grau_hierarquico_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.grau_hierarquico_grhi_cd_grau_hierarquico_seq OWNER TO admint2mbi;

--
-- Name: grau_hierarquico_grhi_cd_grau_hierarquico_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.grau_hierarquico_grhi_cd_grau_hierarquico_seq OWNED BY t2mbi.grau_hierarquico.grhi_cd_grau_hierarquico;


--
-- Name: nacionalidade; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.nacionalidade (
    naci_cd_nacionalidade integer NOT NULL,
    naci_nm_nacionalidade character varying NOT NULL
);


ALTER TABLE t2mbi.nacionalidade OWNER TO admint2mbi;

--
-- Name: nacionalidade_naci_cd_nacionalidade_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.nacionalidade_naci_cd_nacionalidade_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.nacionalidade_naci_cd_nacionalidade_seq OWNER TO admint2mbi;

--
-- Name: nacionalidade_naci_cd_nacionalidade_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.nacionalidade_naci_cd_nacionalidade_seq OWNED BY t2mbi.nacionalidade.naci_cd_nacionalidade;


--
-- Name: naturalidade; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.naturalidade (
    natu_cd_naturalidade integer NOT NULL,
    natu_nm_naturalidade character varying NOT NULL
);


ALTER TABLE t2mbi.naturalidade OWNER TO admint2mbi;

--
-- Name: naturalidade_natu_cd_naturalidade_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.naturalidade_natu_cd_naturalidade_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.naturalidade_natu_cd_naturalidade_seq OWNER TO admint2mbi;

--
-- Name: naturalidade_natu_cd_naturalidade_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.naturalidade_natu_cd_naturalidade_seq OWNED BY t2mbi.naturalidade.natu_cd_naturalidade;


--
-- Name: saude_seguranca; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.saude_seguranca (
    sase_cd_saude_seguranca integer NOT NULL,
    cola_cd_colaborador integer NOT NULL,
    tiex_cd_tipo_exame integer NOT NULL,
    sase_dt_realizacao_exame date NOT NULL,
    sase_nm_doutor_exame character varying NOT NULL,
    sase_nr_crm bigint NOT NULL,
    sase_tx_icd character varying NOT NULL,
    sase_ds_exame character varying NOT NULL,
    sase_in_status character(1) NOT NULL,
    sase_in_apto character(1) NOT NULL,
    sase_dt_proximo_exame date,
    sase_nr_dias_folga integer NOT NULL
);


ALTER TABLE t2mbi.saude_seguranca OWNER TO admint2mbi;

--
-- Name: saude_seguranca_sase_cd_saude_seguranca_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.saude_seguranca_sase_cd_saude_seguranca_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.saude_seguranca_sase_cd_saude_seguranca_seq OWNER TO admint2mbi;

--
-- Name: saude_seguranca_sase_cd_saude_seguranca_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.saude_seguranca_sase_cd_saude_seguranca_seq OWNED BY t2mbi.saude_seguranca.sase_cd_saude_seguranca;


--
-- Name: tipo_beneficio; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.tipo_beneficio (
    tibe_cd_tipo_beneficio integer NOT NULL,
    tibe_nm_tipo_beneficio character varying NOT NULL
);


ALTER TABLE t2mbi.tipo_beneficio OWNER TO admint2mbi;

--
-- Name: tipo_beneficio_tibe_cd_tipo_beneficio_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.tipo_beneficio_tibe_cd_tipo_beneficio_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.tipo_beneficio_tibe_cd_tipo_beneficio_seq OWNER TO admint2mbi;

--
-- Name: tipo_beneficio_tibe_cd_tipo_beneficio_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.tipo_beneficio_tibe_cd_tipo_beneficio_seq OWNED BY t2mbi.tipo_beneficio.tibe_cd_tipo_beneficio;


--
-- Name: tipo_contato; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.tipo_contato (
    tico_cd_tipo_contato integer NOT NULL,
    tico_nm_tipo_contato character varying NOT NULL
);


ALTER TABLE t2mbi.tipo_contato OWNER TO admint2mbi;

--
-- Name: tipo_contato_tico_cd_tipo_contato_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.tipo_contato_tico_cd_tipo_contato_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.tipo_contato_tico_cd_tipo_contato_seq OWNER TO admint2mbi;

--
-- Name: tipo_contato_tico_cd_tipo_contato_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.tipo_contato_tico_cd_tipo_contato_seq OWNED BY t2mbi.tipo_contato.tico_cd_tipo_contato;


--
-- Name: tipo_contrato; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.tipo_contrato (
    ticn_cd_tipo_contrato integer NOT NULL,
    ticn_nm_tipo_contrato character varying NOT NULL
);


ALTER TABLE t2mbi.tipo_contrato OWNER TO admint2mbi;

--
-- Name: tipo_contrato_ticn_cd_tipo_contrato_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.tipo_contrato_ticn_cd_tipo_contrato_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.tipo_contrato_ticn_cd_tipo_contrato_seq OWNER TO admint2mbi;

--
-- Name: tipo_contrato_ticn_cd_tipo_contrato_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.tipo_contrato_ticn_cd_tipo_contrato_seq OWNED BY t2mbi.tipo_contrato.ticn_cd_tipo_contrato;


--
-- Name: tipo_exame; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.tipo_exame (
    tiex_cd_tipo_exame integer NOT NULL,
    tiex_nm_tipo_exame character varying NOT NULL
);


ALTER TABLE t2mbi.tipo_exame OWNER TO admint2mbi;

--
-- Name: tipo_exame_tiex_cd_tipo_exame_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.tipo_exame_tiex_cd_tipo_exame_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.tipo_exame_tiex_cd_tipo_exame_seq OWNER TO admint2mbi;

--
-- Name: tipo_exame_tiex_cd_tipo_exame_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.tipo_exame_tiex_cd_tipo_exame_seq OWNED BY t2mbi.tipo_exame.tiex_cd_tipo_exame;


--
-- Name: tipo_relacionamento; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.tipo_relacionamento (
    tire_cd_tipo_relacionamento integer NOT NULL,
    tire_nm_tipo_relacionameto character varying NOT NULL
);


ALTER TABLE t2mbi.tipo_relacionamento OWNER TO admint2mbi;

--
-- Name: tipo_relacionamento_tire_cd_tipo_relacionamento_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.tipo_relacionamento_tire_cd_tipo_relacionamento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.tipo_relacionamento_tire_cd_tipo_relacionamento_seq OWNER TO admint2mbi;

--
-- Name: tipo_relacionamento_tire_cd_tipo_relacionamento_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.tipo_relacionamento_tire_cd_tipo_relacionamento_seq OWNED BY t2mbi.tipo_relacionamento.tire_cd_tipo_relacionamento;


--
-- Name: turno; Type: TABLE; Schema: t2mbi; Owner: admint2mbi
--

CREATE TABLE t2mbi.turno (
    turn_cd_turno integer NOT NULL,
    turn_nm_turno character varying NOT NULL
);


ALTER TABLE t2mbi.turno OWNER TO admint2mbi;

--
-- Name: turno_turn_cd_turno_seq; Type: SEQUENCE; Schema: t2mbi; Owner: admint2mbi
--

CREATE SEQUENCE t2mbi.turno_turn_cd_turno_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE t2mbi.turno_turn_cd_turno_seq OWNER TO admint2mbi;

--
-- Name: turno_turn_cd_turno_seq; Type: SEQUENCE OWNED BY; Schema: t2mbi; Owner: admint2mbi
--

ALTER SEQUENCE t2mbi.turno_turn_cd_turno_seq OWNED BY t2mbi.turno.turn_cd_turno;


--
-- Name: beneficio bene_cd_beneficio; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.beneficio ALTER COLUMN bene_cd_beneficio SET DEFAULT nextval('t2mbi.beneficio_bene_cd_beneficio_seq'::regclass);


--
-- Name: colaborador cola_cd_colaborador; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador ALTER COLUMN cola_cd_colaborador SET DEFAULT nextval('t2mbi.colaborador_cola_cd_colaborador_seq'::regclass);


--
-- Name: contato cont_cd_contato; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contato ALTER COLUMN cont_cd_contato SET DEFAULT nextval('t2mbi.contato_cont_cd_contato_seq'::regclass);


--
-- Name: contrato cotr_cd_contrato; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contrato ALTER COLUMN cotr_cd_contrato SET DEFAULT nextval('t2mbi.contrato_cotr_cd_contrato_seq'::regclass);


--
-- Name: departamento depa_cd_departamento; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.departamento ALTER COLUMN depa_cd_departamento SET DEFAULT nextval('t2mbi.departamento_depa_cd_departamento_seq'::regclass);


--
-- Name: dependente depe_cd_dependente; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.dependente ALTER COLUMN depe_cd_dependente SET DEFAULT nextval('t2mbi.dependente_depe_cd_dependente_seq'::regclass);


--
-- Name: estado_civil esci_cd_estado_civil; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.estado_civil ALTER COLUMN esci_cd_estado_civil SET DEFAULT nextval('t2mbi.estado_civil_esci_cd_estado_civil_seq'::regclass);


--
-- Name: ferias feri_cd_ferias; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.ferias ALTER COLUMN feri_cd_ferias SET DEFAULT nextval('t2mbi.ferias_feri_cd_ferias_seq'::regclass);


--
-- Name: genero gene_cd_genero; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.genero ALTER COLUMN gene_cd_genero SET DEFAULT nextval('t2mbi.genero_gene_cd_genero_seq'::regclass);


--
-- Name: grau_educacional gred_cd_grau_educacional; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.grau_educacional ALTER COLUMN gred_cd_grau_educacional SET DEFAULT nextval('t2mbi.grau_educacional_gred_cd_grau_educacional_seq'::regclass);


--
-- Name: grau_hierarquico grhi_cd_grau_hierarquico; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.grau_hierarquico ALTER COLUMN grhi_cd_grau_hierarquico SET DEFAULT nextval('t2mbi.grau_hierarquico_grhi_cd_grau_hierarquico_seq'::regclass);


--
-- Name: nacionalidade naci_cd_nacionalidade; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.nacionalidade ALTER COLUMN naci_cd_nacionalidade SET DEFAULT nextval('t2mbi.nacionalidade_naci_cd_nacionalidade_seq'::regclass);


--
-- Name: naturalidade natu_cd_naturalidade; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.naturalidade ALTER COLUMN natu_cd_naturalidade SET DEFAULT nextval('t2mbi.naturalidade_natu_cd_naturalidade_seq'::regclass);


--
-- Name: saude_seguranca sase_cd_saude_seguranca; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.saude_seguranca ALTER COLUMN sase_cd_saude_seguranca SET DEFAULT nextval('t2mbi.saude_seguranca_sase_cd_saude_seguranca_seq'::regclass);


--
-- Name: tipo_beneficio tibe_cd_tipo_beneficio; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_beneficio ALTER COLUMN tibe_cd_tipo_beneficio SET DEFAULT nextval('t2mbi.tipo_beneficio_tibe_cd_tipo_beneficio_seq'::regclass);


--
-- Name: tipo_contato tico_cd_tipo_contato; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_contato ALTER COLUMN tico_cd_tipo_contato SET DEFAULT nextval('t2mbi.tipo_contato_tico_cd_tipo_contato_seq'::regclass);


--
-- Name: tipo_contrato ticn_cd_tipo_contrato; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_contrato ALTER COLUMN ticn_cd_tipo_contrato SET DEFAULT nextval('t2mbi.tipo_contrato_ticn_cd_tipo_contrato_seq'::regclass);


--
-- Name: tipo_exame tiex_cd_tipo_exame; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_exame ALTER COLUMN tiex_cd_tipo_exame SET DEFAULT nextval('t2mbi.tipo_exame_tiex_cd_tipo_exame_seq'::regclass);


--
-- Name: tipo_relacionamento tire_cd_tipo_relacionamento; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_relacionamento ALTER COLUMN tire_cd_tipo_relacionamento SET DEFAULT nextval('t2mbi.tipo_relacionamento_tire_cd_tipo_relacionamento_seq'::regclass);


--
-- Name: turno turn_cd_turno; Type: DEFAULT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.turno ALTER COLUMN turn_cd_turno SET DEFAULT nextval('t2mbi.turno_turn_cd_turno_seq'::regclass);


--
-- Data for Name: beneficio; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4253.dat

--
-- Data for Name: colaborador; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4255.dat

--
-- Data for Name: colaborador_beneficio; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4256.dat

--
-- Data for Name: colaborador_contrato; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4258.dat

--
-- Data for Name: colaborador_departamento; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4259.dat

--
-- Data for Name: contato; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4260.dat

--
-- Data for Name: contrato; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4262.dat

--
-- Data for Name: departamento; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4264.dat

--
-- Data for Name: dependente; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4266.dat

--
-- Data for Name: estado_civil; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4268.dat

--
-- Data for Name: ferias; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4270.dat

--
-- Data for Name: genero; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4272.dat

--
-- Data for Name: grau_educacional; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4274.dat

--
-- Data for Name: grau_hierarquico; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4276.dat

--
-- Data for Name: nacionalidade; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4278.dat

--
-- Data for Name: naturalidade; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4280.dat

--
-- Data for Name: saude_seguranca; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4282.dat

--
-- Data for Name: tipo_beneficio; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4284.dat

--
-- Data for Name: tipo_contato; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4286.dat

--
-- Data for Name: tipo_contrato; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4288.dat

--
-- Data for Name: tipo_exame; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4290.dat

--
-- Data for Name: tipo_relacionamento; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4292.dat

--
-- Data for Name: turno; Type: TABLE DATA; Schema: t2mbi; Owner: admint2mbi
--

\i $$PATH$$/4294.dat

--
-- Name: beneficio_bene_cd_beneficio_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.beneficio_bene_cd_beneficio_seq', 32, true);


--
-- Name: colaborador_cola_cd_colaborador_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.colaborador_cola_cd_colaborador_seq', 68, true);


--
-- Name: contato_cont_cd_contato_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.contato_cont_cd_contato_seq', 68, true);


--
-- Name: contrato_cotr_cd_contrato_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.contrato_cotr_cd_contrato_seq', 14, true);


--
-- Name: departamento_depa_cd_departamento_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.departamento_depa_cd_departamento_seq', 25, true);


--
-- Name: dependente_depe_cd_dependente_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.dependente_depe_cd_dependente_seq', 37, true);


--
-- Name: estado_civil_esci_cd_estado_civil_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.estado_civil_esci_cd_estado_civil_seq', 6, true);


--
-- Name: ferias_feri_cd_ferias_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.ferias_feri_cd_ferias_seq', 23, true);


--
-- Name: genero_gene_cd_genero_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.genero_gene_cd_genero_seq', 3, true);


--
-- Name: grau_educacional_gred_cd_grau_educacional_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.grau_educacional_gred_cd_grau_educacional_seq', 7, true);


--
-- Name: grau_hierarquico_grhi_cd_grau_hierarquico_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.grau_hierarquico_grhi_cd_grau_hierarquico_seq', 3, true);


--
-- Name: nacionalidade_naci_cd_nacionalidade_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.nacionalidade_naci_cd_nacionalidade_seq', 2, true);


--
-- Name: naturalidade_natu_cd_naturalidade_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.naturalidade_natu_cd_naturalidade_seq', 18, true);


--
-- Name: saude_seguranca_sase_cd_saude_seguranca_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.saude_seguranca_sase_cd_saude_seguranca_seq', 26, true);


--
-- Name: tipo_beneficio_tibe_cd_tipo_beneficio_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.tipo_beneficio_tibe_cd_tipo_beneficio_seq', 13, true);


--
-- Name: tipo_contato_tico_cd_tipo_contato_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.tipo_contato_tico_cd_tipo_contato_seq', 14, true);


--
-- Name: tipo_contrato_ticn_cd_tipo_contrato_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.tipo_contrato_ticn_cd_tipo_contrato_seq', 6, true);


--
-- Name: tipo_exame_tiex_cd_tipo_exame_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.tipo_exame_tiex_cd_tipo_exame_seq', 11, true);


--
-- Name: tipo_relacionamento_tire_cd_tipo_relacionamento_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.tipo_relacionamento_tire_cd_tipo_relacionamento_seq', 9, true);


--
-- Name: turno_turn_cd_turno_seq; Type: SEQUENCE SET; Schema: t2mbi; Owner: admint2mbi
--

SELECT pg_catalog.setval('t2mbi.turno_turn_cd_turno_seq', 5, true);


--
-- Name: beneficio pk_bene; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.beneficio
    ADD CONSTRAINT pk_bene PRIMARY KEY (bene_cd_beneficio);


--
-- Name: colaborador_beneficio pk_cobe; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_beneficio
    ADD CONSTRAINT pk_cobe PRIMARY KEY (bene_cd_beneficio, cola_cd_colaborador);


--
-- Name: colaborador_contrato pk_coco; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_contrato
    ADD CONSTRAINT pk_coco PRIMARY KEY (cotr_cd_contrato, cola_cd_colaborador);


--
-- Name: colaborador_departamento pk_code; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_departamento
    ADD CONSTRAINT pk_code PRIMARY KEY (cola_cd_colaborador, depa_cd_departamento);


--
-- Name: colaborador pk_cola; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT pk_cola PRIMARY KEY (cola_cd_colaborador);


--
-- Name: contato pk_cont; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contato
    ADD CONSTRAINT pk_cont PRIMARY KEY (cont_cd_contato);


--
-- Name: contrato pk_cotr; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contrato
    ADD CONSTRAINT pk_cotr PRIMARY KEY (cotr_cd_contrato);


--
-- Name: departamento pk_depa; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.departamento
    ADD CONSTRAINT pk_depa PRIMARY KEY (depa_cd_departamento);


--
-- Name: dependente pk_depe; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.dependente
    ADD CONSTRAINT pk_depe PRIMARY KEY (depe_cd_dependente);


--
-- Name: estado_civil pk_esci; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.estado_civil
    ADD CONSTRAINT pk_esci PRIMARY KEY (esci_cd_estado_civil);


--
-- Name: ferias pk_feri; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.ferias
    ADD CONSTRAINT pk_feri PRIMARY KEY (feri_cd_ferias);


--
-- Name: genero pk_gene; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.genero
    ADD CONSTRAINT pk_gene PRIMARY KEY (gene_cd_genero);


--
-- Name: grau_educacional pk_gred; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.grau_educacional
    ADD CONSTRAINT pk_gred PRIMARY KEY (gred_cd_grau_educacional);


--
-- Name: grau_hierarquico pk_grhi; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.grau_hierarquico
    ADD CONSTRAINT pk_grhi PRIMARY KEY (grhi_cd_grau_hierarquico);


--
-- Name: nacionalidade pk_naci; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.nacionalidade
    ADD CONSTRAINT pk_naci PRIMARY KEY (naci_cd_nacionalidade);


--
-- Name: naturalidade pk_natu; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.naturalidade
    ADD CONSTRAINT pk_natu PRIMARY KEY (natu_cd_naturalidade);


--
-- Name: saude_seguranca pk_sase; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.saude_seguranca
    ADD CONSTRAINT pk_sase PRIMARY KEY (sase_cd_saude_seguranca);


--
-- Name: tipo_beneficio pk_tibe; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_beneficio
    ADD CONSTRAINT pk_tibe PRIMARY KEY (tibe_cd_tipo_beneficio);


--
-- Name: tipo_contrato pk_ticn; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_contrato
    ADD CONSTRAINT pk_ticn PRIMARY KEY (ticn_cd_tipo_contrato);


--
-- Name: tipo_contato pk_tico; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_contato
    ADD CONSTRAINT pk_tico PRIMARY KEY (tico_cd_tipo_contato);


--
-- Name: tipo_exame pk_tiex; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_exame
    ADD CONSTRAINT pk_tiex PRIMARY KEY (tiex_cd_tipo_exame);


--
-- Name: tipo_relacionamento pk_tire; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.tipo_relacionamento
    ADD CONSTRAINT pk_tire PRIMARY KEY (tire_cd_tipo_relacionamento);


--
-- Name: turno pk_turn; Type: CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.turno
    ADD CONSTRAINT pk_turn PRIMARY KEY (turn_cd_turno);


--
-- Name: colaborador_beneficio fk_bene_cobe; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_beneficio
    ADD CONSTRAINT fk_bene_cobe FOREIGN KEY (bene_cd_beneficio) REFERENCES t2mbi.beneficio(bene_cd_beneficio);


--
-- Name: colaborador_beneficio fk_cola_cobe; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_beneficio
    ADD CONSTRAINT fk_cola_cobe FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: colaborador_contrato fk_cola_coco; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_contrato
    ADD CONSTRAINT fk_cola_coco FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: colaborador_departamento fk_cola_code; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_departamento
    ADD CONSTRAINT fk_cola_code FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: contato fk_cola_cont; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contato
    ADD CONSTRAINT fk_cola_cont FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: dependente fk_cola_depe; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.dependente
    ADD CONSTRAINT fk_cola_depe FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: ferias fk_cola_feri; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.ferias
    ADD CONSTRAINT fk_cola_feri FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: saude_seguranca fk_cola_sase; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.saude_seguranca
    ADD CONSTRAINT fk_cola_sase FOREIGN KEY (cola_cd_colaborador) REFERENCES t2mbi.colaborador(cola_cd_colaborador);


--
-- Name: colaborador_contrato fk_cotr_coco; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_contrato
    ADD CONSTRAINT fk_cotr_coco FOREIGN KEY (cotr_cd_contrato) REFERENCES t2mbi.contrato(cotr_cd_contrato);


--
-- Name: colaborador_departamento fk_depa_code; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador_departamento
    ADD CONSTRAINT fk_depa_code FOREIGN KEY (depa_cd_departamento) REFERENCES t2mbi.departamento(depa_cd_departamento);


--
-- Name: colaborador fk_esci_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_esci_cola FOREIGN KEY (esci_cd_estado_civil) REFERENCES t2mbi.estado_civil(esci_cd_estado_civil);


--
-- Name: colaborador fk_gene_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_gene_cola FOREIGN KEY (gene_cd_genero) REFERENCES t2mbi.genero(gene_cd_genero);


--
-- Name: colaborador fk_gred_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_gred_cola FOREIGN KEY (gred_cd_grau_educacional) REFERENCES t2mbi.grau_educacional(gred_cd_grau_educacional);


--
-- Name: colaborador fk_grhi_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_grhi_cola FOREIGN KEY (grhi_cd_grau_hierarquico) REFERENCES t2mbi.grau_hierarquico(grhi_cd_grau_hierarquico);


--
-- Name: colaborador fk_naci_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_naci_cola FOREIGN KEY (naci_cd_nacionalidade) REFERENCES t2mbi.nacionalidade(naci_cd_nacionalidade);


--
-- Name: colaborador fk_natu_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_natu_cola FOREIGN KEY (natu_cd_naturalidade) REFERENCES t2mbi.naturalidade(natu_cd_naturalidade);


--
-- Name: beneficio fk_tibe_bene; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.beneficio
    ADD CONSTRAINT fk_tibe_bene FOREIGN KEY (tibe_cd_tipo_beneficio) REFERENCES t2mbi.tipo_beneficio(tibe_cd_tipo_beneficio);


--
-- Name: colaborador fk_ticn_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_ticn_cola FOREIGN KEY (ticn_cd_tipo_contrato) REFERENCES t2mbi.tipo_contrato(ticn_cd_tipo_contrato);


--
-- Name: contato fk_tico_cont; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.contato
    ADD CONSTRAINT fk_tico_cont FOREIGN KEY (tico_cd_tipo_contato) REFERENCES t2mbi.tipo_contato(tico_cd_tipo_contato);


--
-- Name: saude_seguranca fk_tiex_sase; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.saude_seguranca
    ADD CONSTRAINT fk_tiex_sase FOREIGN KEY (tiex_cd_tipo_exame) REFERENCES t2mbi.tipo_exame(tiex_cd_tipo_exame);


--
-- Name: dependente fk_tire_depe; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.dependente
    ADD CONSTRAINT fk_tire_depe FOREIGN KEY (tire_cd_tipo_relacionamento) REFERENCES t2mbi.tipo_relacionamento(tire_cd_tipo_relacionamento);


--
-- Name: colaborador fk_turn_cola; Type: FK CONSTRAINT; Schema: t2mbi; Owner: admint2mbi
--

ALTER TABLE ONLY t2mbi.colaborador
    ADD CONSTRAINT fk_turn_cola FOREIGN KEY (turn_cd_turno) REFERENCES t2mbi.turno(turn_cd_turno);


--
-- Name: SCHEMA t2mbi; Type: ACL; Schema: -; Owner: admint2mbi
--

GRANT ALL ON SCHEMA t2mbi TO alunos;


--
-- Name: TABLE beneficio; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.beneficio TO alunos;


--
-- Name: TABLE colaborador; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.colaborador TO alunos;


--
-- Name: TABLE colaborador_beneficio; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.colaborador_beneficio TO alunos;


--
-- Name: TABLE colaborador_contrato; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.colaborador_contrato TO alunos;


--
-- Name: TABLE colaborador_departamento; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.colaborador_departamento TO alunos;


--
-- Name: TABLE contato; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.contato TO alunos;


--
-- Name: TABLE contrato; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.contrato TO alunos;


--
-- Name: TABLE departamento; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.departamento TO alunos;


--
-- Name: TABLE dependente; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.dependente TO alunos;


--
-- Name: TABLE estado_civil; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.estado_civil TO alunos;


--
-- Name: TABLE ferias; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.ferias TO alunos;


--
-- Name: TABLE genero; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.genero TO alunos;


--
-- Name: TABLE grau_educacional; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.grau_educacional TO alunos;


--
-- Name: TABLE grau_hierarquico; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.grau_hierarquico TO alunos;


--
-- Name: TABLE nacionalidade; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.nacionalidade TO alunos;


--
-- Name: TABLE naturalidade; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.naturalidade TO alunos;


--
-- Name: TABLE saude_seguranca; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.saude_seguranca TO alunos;


--
-- Name: TABLE tipo_beneficio; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.tipo_beneficio TO alunos;


--
-- Name: TABLE tipo_contato; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.tipo_contato TO alunos;


--
-- Name: TABLE tipo_contrato; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.tipo_contrato TO alunos;


--
-- Name: TABLE tipo_exame; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.tipo_exame TO alunos;


--
-- Name: TABLE tipo_relacionamento; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.tipo_relacionamento TO alunos;


--
-- Name: TABLE turno; Type: ACL; Schema: t2mbi; Owner: admint2mbi
--

GRANT SELECT ON TABLE t2mbi.turno TO alunos;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: t2mbi; Owner: admint2mbi
--

ALTER DEFAULT PRIVILEGES FOR ROLE admint2mbi IN SCHEMA t2mbi GRANT SELECT ON TABLES TO alunos;


--
-- PostgreSQL database dump complete
--

